# Not a contribution
# Changes made by NVIDIA CORPORATION & AFFILIATES enabling BLADE or otherwise documented as
# NVIDIA-proprietary are not a contribution and subject to the following terms and conditions:
#
# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.
#
# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: LicenseRef-NvidiaProprietary
#
# NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
# property and proprietary rights in and to this material, related
# documentation and any modifications thereto. Any use, reproduction,
# disclosure or distribution of this material and related documentation
# without an express license agreement from NVIDIA CORPORATION or
# its affiliates is strictly prohibited.

# Copyright (c) 2023 Max Planck Society
# License: https://bedlam.is.tuebingen.mpg.de/license.html
#
# Create level sequences for specified animations in be_seq.csv file
#
# Required plugins: Python Editor Script Plugin, Editor Scripting, Sequencer Scripting
#
# Changes for BEDLAM-CC dataset presented in BLADE: Single-view Body Mesh Learning through Accurate Depth Estimation
# [ Shengze Wang, Jiefeng Li, Tianye Li, Ye Yuan, Henry Fuchs, Koki Nagano, Shalini De Mello, Michael Stengel ]

import csv
from dataclasses import dataclass
import re
from math import radians, tan
import sys
import time
import unreal

import math
import random
import os
import numpy as np

import smplx as smpl

import torch
import torch.nn as nn
import torch.nn.functional as F

# Globals
WARMUP_FRAMES = 10 # Needed for proper temporal sampling on frame 0 of animations and raytracing warmup. These frames are rendered out with negative numbers and will be deleted in post render pipeline.
data_root_unreal = "/Engine/PS/Bedlam/"
clothing_actor_class_path = data_root_unreal + "Core/Materials/BE_ClothingOverlayActor.BE_ClothingOverlayActor_C"
body_root = data_root_unreal + "SMPLX/"
hair_root = data_root_unreal + "Hair/CC/Meshes/"
animation_root = data_root_unreal + "SMPLX_batch01_hand_animations/"
hdri_root = data_root_unreal + "HDRI/4k/"
hdri_suffix = ""

material_body_root = "/Engine/PS/Meshcapade/SMPL/Materials"
material_clothing_root = data_root_unreal + "Clothing/Materials"
texture_body_root = "/Engine/PS/Meshcapade/SMPL/MC_texture_skintones"
texture_clothing_overlay_root = data_root_unreal + "Clothing/MaterialsSMPLX/Textures"

material_hidden_name = data_root_unreal + "Core/Materials/M_SMPLX_Hidden"

bedlam_root = "/Game/Bedlam/"
level_sequence_hdri_template = bedlam_root + "LS_Template_HDRI"
level_sequences_root = bedlam_root + "LevelSequences/"
camera_root = bedlam_root + "CameraMovement/"

csv_path            = "C:/blade/blade_seq_1_1.csv" # default csv 
animationRootDir    = "C:/blade/animations/gendered_ground_truth/"

################################################################################

class SmplxModel():

    device = 'cuda'

    def __init__( self):

        model_path          = 'C:/blade/assets/'
        smplx_path          = model_path + 'smplx/'
        smplx_npz_path      = smplx_path + 'SMPLX_NEUTRAL.npz'

        print('init smlpx model...')
        print(os.getcwd())

        model_data = np.load(smplx_npz_path, allow_pickle=True)
        for k in model_data.keys():
            print(k)
                
        self.kintree_table  = model_data['kintree_table'] # kinematic tree
        self.indices        = model_data['f'] #  vertex indices for rendering

        dtype = torch.float64
        self.model_params = dict(model_path=model_path,
                            model_type='smplx',
                            create_global_orient=True,
                            create_body_pose=True,
                            create_betas=True,
                            num_betas=300,
                            create_left_hand_pose=True,
                            create_right_hand_pose=True,
                            use_pca=False,
                            flat_hand_mean=False,
                            create_expression=True,
                            num_expression_coeffs=100,
                            num_pca_comps=12,
                            create_jaw_pose=True,
                            create_leye_pose=True,
                            create_reye_pose=True,
                            create_transl=False,
                            # gender='ne',
                            dtype=dtype, )
        
        self.smplx_model = smpl.create(**self.model_params).to(self.device)

        self.betas              = np.zeros([300], dtype=np.float32)
        self.jaw_pose           = np.zeros([3], dtype=np.float32)
        self.leye_pose          = np.zeros([3], dtype=np.float32)
        self.reye_pose          = np.zeros([3], dtype=np.float32)
        self.global_orient      = np.zeros([3], dtype=np.float32)
        self.body_pose          = np.zeros([63], dtype=np.float32)
        self.left_hand_pose     = np.zeros([45], dtype=np.float32)
        self.right_hand_pose    = np.zeros([45], dtype=np.float32)
        self.expression         = np.zeros([100], dtype=np.float32)

        self.translation        = np.zeros([3], dtype=np.float32)

        self.recomputeJointPositions()

    def recomputeJointPositions(self):
        
        #'betas', 'body_pose', 'expression', 'full_pose', 'get', 'global_orient', 'items', 'jaw_pose', 'joints', 'keys', 'left_hand_pose', 'right_hand_pose', 'transl', 'v_shaped', 'values', 'vertices']

        self.model_output = self.smplx_model(betas=torch.from_numpy(self.betas.astype(dtype=np.float64)).unsqueeze(dim=0).to(self.device),
                            expression=torch.from_numpy(self.expression.astype(dtype=np.float64)).unsqueeze(dim=0).to(self.device),
                            jaw_pose=torch.from_numpy(self.jaw_pose.astype(dtype=np.float64)).unsqueeze(dim=0).to(self.device),
                            leye_pose=torch.from_numpy(self.leye_pose.astype(dtype=np.float64)).unsqueeze(dim=0).to(self.device),
                            reye_pose=torch.from_numpy(self.reye_pose.astype(dtype=np.float64)).unsqueeze(dim=0).to(self.device),
                            global_orient=torch.from_numpy(self.global_orient.astype(dtype=np.float64)).unsqueeze(dim=0).to(self.device),
                            body_pose=torch.from_numpy(self.body_pose.astype(dtype=np.float64)).unsqueeze(dim=0).to(self.device),
                            left_hand_pose=torch.from_numpy(self.left_hand_pose.astype(dtype=np.float64)).unsqueeze(dim=0).to(self.device),
                            right_hand_pose=torch.from_numpy(self.right_hand_pose.astype(dtype=np.float64)).unsqueeze(dim=0).to(self.device),
                            return_verts=True)
        
        self.joint_positions = self.model_output.joints.cpu().detach().numpy() + self.translation

    def recomputeJointPositionsFromConcatPose(self, concat_pose):     
        
            self.jaw_pose           = concat_pose[0:3] # 3
            self.leye_pose          = concat_pose[3:6] # 3
            self.reye_pose          = concat_pose[6:9] # 3
            self.global_orient      = concat_pose[9:12]  # 3   
            self.body_pose          = concat_pose[12:75] # 62
            self.left_hand_pose     = concat_pose[75:120] # 45
            self.right_hand_pose    = concat_pose[120:165] # 45
            self.expression         = concat_pose[165:265] # 100

            self.translation        = concat_pose[265:265+3] # 3

            self.recomputeJointPositions()

smplxModel = SmplxModel()

@dataclass
class SequenceBody:
    subject: str
    body_path: str
    clothing_path: str
    hair_path: str
    animation_path: str
    x: float
    y: float
    z: float
    yaw: float
    pitch: float
    roll: float
    start_frame: int
    texture_body: str
    texture_clothing: str
    texture_clothing_overlay: str

@dataclass
class CameraPose:
    x: float
    y: float
    z: float
    yaw: float
    pitch: float
    roll: float

################################################################################

def add_geometry_cache(level_sequence, sequence_body_index, layer_suffix, start_frame, end_frame, target_object, x, y, z, yaw, pitch, roll, material=None, texture_body_path=None, texture_clothing_overlay_path=None):
    """
    Add geometry cache to LevelSequence and setup material.
    If material parameter is set then GeometryCacheActor will be spawned and the material will be used.
    Otherwise a custom clothing actor (SMPLXClothingActor) will be spawned and the provided texture inputs will be used.
    """

    # Spawned GeometryCaches will generate GeometryCacheActors where ManualTick is false by default.
    # This will cause the animation to play before the animation section in the timeline and lead to temporal sampling errors
    # on the first frame of the animation section.
    # To prevent this we need to set ManualTick to true as default setting for the GeometryCacheActor.
    # 1. Spawn default GeometryCacheActor template in level
    # 2. Set default settings for GeometryCache and ManualTick on it
    # 3. Add actor as spawnable to sequence
    # 4. Destroy template actor in level
    # Note: Conversion from possessable to spawnable currently not available in Python: https://forums.unrealengine.com/t/convert-to-spawnable-with-python/509827

    if texture_clothing_overlay_path is not None:
        # Use SMPL-X clothing overlay texture, dynamic material instance will be generated in BE_ClothingOverlayActor Construction Script
        clothing_actor_class = unreal.load_class(None, clothing_actor_class_path)
        geometry_cache_actor = unreal.get_editor_subsystem(unreal.EditorActorSubsystem).spawn_actor_from_class(clothing_actor_class, unreal.Vector(0,0,0))
        geometry_cache_actor.set_editor_property("bodytexture", unreal.SystemLibrary.conv_soft_obj_path_to_soft_obj_ref(unreal.SoftObjectPath(texture_body_path)))
        geometry_cache_actor.set_editor_property("clothingtextureoverlay", unreal.SystemLibrary.conv_soft_obj_path_to_soft_obj_ref(unreal.SoftObjectPath(texture_clothing_overlay_path)))
    else:
        geometry_cache_actor = unreal.get_editor_subsystem(unreal.EditorActorSubsystem).spawn_actor_from_class(unreal.GeometryCacheActor, unreal.Vector(0,0,0))
        if material is not None:
            geometry_cache_actor.get_geometry_cache_component().set_material(0, material)


    geometry_cache_actor.set_actor_label(target_object.get_name())
    geometry_cache_actor.get_geometry_cache_component().set_editor_property("looping", False) # disable looping to prevent ghosting on last frame with temporal sampling
    geometry_cache_actor.get_geometry_cache_component().set_editor_property("manual_tick", True)
    geometry_cache_actor.get_geometry_cache_component().set_editor_property("geometry_cache", target_object)

    # Add actor to new layer so that we can later use layer name when generating segmentation masks names.
    # Note: We cannot use ObjectIds of type "Actor" since actors which are added via add_spawnable_from_instance() will later use their class names when generating ObjectIds of type Actor.
    layer_subsystem = unreal.get_editor_subsystem(unreal.LayersSubsystem)
    layer_subsystem.add_actor_to_layer(geometry_cache_actor, f"be_actor_{sequence_body_index:02}_{layer_suffix}")


    body_binding = level_sequence.add_spawnable_from_instance(geometry_cache_actor)
    unreal.get_editor_subsystem(unreal.EditorActorSubsystem).destroy_actor(geometry_cache_actor) # Delete temporary template actor from level

    geometry_cache_track = body_binding.add_track(unreal.MovieSceneGeometryCacheTrack)
    geometry_cache_section = geometry_cache_track.add_section()
    geometry_cache_section.set_range(start_frame, end_frame)

    # TODO properly set Geometry Cache target in geometry_cache_section properties to have same behavior as manual setup
    #
    # Not working: geometry_cache_section.set_editor_property("GeometryCache", body_object)
    #   Exception: MovieSceneGeometryCacheTrack: Failed to find property 'GeometryCache' for attribute 'GeometryCache' on 'MovieSceneGeometryCacheTrack'
    
    transform_track = body_binding.add_track(unreal.MovieScene3DTransformTrack)
    transform_section = transform_track.add_section()
    transform_section.set_start_frame_bounded(False)
    transform_section.set_end_frame_bounded(False)
    transform_channels = transform_section.get_all_channels()
    transform_channels[0].set_default(x) # location X
    transform_channels[1].set_default(y) # location Y
    transform_channels[2].set_default(z) # location Z

    transform_channels[3].set_default(roll)  # roll
    transform_channels[4].set_default(pitch) # pitch
    transform_channels[5].set_default(yaw)   # yaw

    return


def add_hair(level_sequence, sequence_body_index, layer_suffix, start_frame, end_frame, hair_path, animation_path, x, y, z, yaw, pitch, roll,):
    """
    Add hair attached to animation sequence to LevelSequence.
    """

    unreal.log(f"    Loading static hair mesh: {hair_path}")
    hair_object = unreal.load_object(None, hair_path)
    if hair_object is None:
        unreal.log_error("      Cannot load mesh")
        return False

    unreal.log(f"    Loading animation sequence: {animation_path}")
    animsequence_object = unreal.load_asset(animation_path)
    if animsequence_object is None:
        unreal.log_error("      Cannot load animation sequence")
        return False


    animation_path_name = animation_path.split("/")[-1]
    animation_path_root = animation_path.replace(animation_path_name, "")
    skeletal_mesh_path = animation_path_root + animation_path_name.replace("_Anim", "")
    unreal.log(f"    Loading skeletal mesh: {skeletal_mesh_path}")
    skeletal_mesh_object = unreal.load_asset(skeletal_mesh_path)
    if skeletal_mesh_object is None:
        unreal.log_error("      Cannot load skeletal mesh")
        return False

    skeletal_mesh_actor = unreal.get_editor_subsystem(unreal.EditorActorSubsystem).spawn_actor_from_class(unreal.SkeletalMeshActor, unreal.Vector(0,0,0))
    skeletal_mesh_actor.set_actor_label(animsequence_object.get_name())
    skeletal_mesh_actor.skeletal_mesh_component.set_skeletal_mesh(skeletal_mesh_object)

    # Set hidden material to hide the skeletal mesh
    material = unreal.EditorAssetLibrary.load_asset(f"Material'{material_hidden_name}'")
    if not material:
        unreal.log_error('Cannot load hidden material: ' + material_hidden_name)
    skeletal_mesh_actor.skeletal_mesh_component.set_material(0, material)

    hair_actor = unreal.get_editor_subsystem(unreal.EditorActorSubsystem).spawn_actor_from_class(unreal.StaticMeshActor, unreal.Vector(0,0,0))
    hair_actor.set_actor_label(hair_object.get_name())
    hair_actor.set_mobility(unreal.ComponentMobility.MOVABLE)

    hair_actor.static_mesh_component.set_editor_property("static_mesh", hair_object)

    # Add actor to new layer so that we can later use layer name when generating segmentation masks names.
    # Note: We cannot use ObjectIds of type "Actor" since actors which are added via add_spawnable_from_instance() will later use their class names when generating ObjectIds of type Actor.
    layer_subsystem = unreal.get_editor_subsystem(unreal.LayersSubsystem)
    layer_subsystem.add_actor_to_layer(hair_actor, f"be_actor_{sequence_body_index:02}_{layer_suffix}")

    # Setup LevelSequence
    skeletal_mesh_actor_binding = level_sequence.add_spawnable_from_instance(skeletal_mesh_actor)
    hair_actor_binding = level_sequence.add_spawnable_from_instance(hair_actor)

    unreal.get_editor_subsystem(unreal.EditorActorSubsystem).destroy_actor(skeletal_mesh_actor) # Delete temporary template actor from level
    unreal.get_editor_subsystem(unreal.EditorActorSubsystem).destroy_actor(hair_actor) # Delete temporary template actor from level

    anim_track = skeletal_mesh_actor_binding.add_track(unreal.MovieSceneSkeletalAnimationTrack)
    anim_section = anim_track.add_section()
    anim_section.params.animation = animsequence_object
    anim_section.set_range(start_frame, end_frame)

    transform_track = skeletal_mesh_actor_binding.add_track(unreal.MovieScene3DTransformTrack)
    transform_section = transform_track.add_section()
    transform_section.set_start_frame_bounded(False)
    transform_section.set_end_frame_bounded(False)
    transform_channels = transform_section.get_all_channels()
    transform_channels[0].set_default(x) # location X
    transform_channels[1].set_default(y) # location Y
    transform_channels[2].set_default(z) # location Z
    transform_channels[3].set_default(roll)  # roll
    transform_channels[4].set_default(pitch) # pitch
    transform_channels[5].set_default(yaw)   # yaw

    # Attach hair to animation
    attach_track = hair_actor_binding.add_track(unreal.MovieScene3DAttachTrack)
    attach_section = attach_track.add_section() # MovieScene3DAttachSection

    animation_binding_id = unreal.MovieSceneObjectBindingID()
    animation_binding_id.set_editor_property("Guid", skeletal_mesh_actor_binding.get_id())

    attach_section.set_constraint_binding_id(animation_binding_id)
    attach_section.set_editor_property("attach_socket_name", "head")

    attach_section.set_range(start_frame, end_frame)

    return True

def add_transform_track(binding, camera_pose):
    transform_track = binding.add_track(unreal.MovieScene3DTransformTrack)
    transform_section = transform_track.add_section()
    transform_section.set_start_frame_bounded(False)
    transform_section.set_end_frame_bounded(False)
    transform_channels = transform_section.get_all_channels()
    transform_channels[0].set_default(camera_pose.x) # location X
    transform_channels[1].set_default(camera_pose.y) # location Y
    transform_channels[2].set_default(camera_pose.z) # location Z

    transform_channels[3].set_default(camera_pose.roll) # roll
    transform_channels[4].set_default(camera_pose.pitch) # pitch
    transform_channels[5].set_default(camera_pose.yaw) # yaw
    return

def add_transform_track_rotation(binding, camera_pose, numFrames, camOriginMinDistance = 50, camOriginMaxDistance = 250, headPositionSequence=None, minRadiusSequence=None):

    cameraPoses = []

    cameraDistances = []

    transform_track = binding.add_track(unreal.MovieScene3DTransformTrack)
    transform_section = transform_track.add_section()
    transform_section.set_start_frame_bounded(False)
    transform_section.set_end_frame_bounded(False)
    transform_channels = transform_section.get_all_channels()
    transform_channels[0].set_default(camera_pose.x) # location X
    transform_channels[1].set_default(camera_pose.y) # location Y
    transform_channels[2].set_default(camera_pose.z) # location Z

    transform_channels[3].set_default(camera_pose.roll) # roll
    transform_channels[4].set_default(camera_pose.pitch) # pitch
    transform_channels[5].set_default(camera_pose.yaw) # yaw

    if WARMUP_FRAMES > 0:
        transform_channels[5].add_key(time=unreal.FrameNumber(-WARMUP_FRAMES), new_value=-1)
    for frame_number in range (0, numFrames):

        yawAngle = frame_number * 10 # interval in degrees
        transform_channels[5].add_key(time=unreal.FrameNumber(frame_number), new_value=yawAngle)  

        yawAngleDeg = yawAngle + 180
        pitchAngleDeg = camera_pose.pitch
        rollAngleDeg = camera_pose.roll

        # randomize camera distance to actor
        randCameraDistance = random.uniform(camOriginMinDistance, camOriginMaxDistance)

        # randomize camera distance using inverse z 

        minCameraRadius = minRadiusSequence[frame_number] * 1.3 # enlarge to avoid camera / mesh interpeneration

        if (randCameraDistance < minCameraRadius):
            #print(f"Override camera distance {randCameraDistance} with {minRadiusSequence[frame_number]} for geometry collision avoidance in frame {frame_number}")
            randCameraDistance = max(minCameraRadius, randCameraDistance) # potentially increase distance to avoid clipped geometry

        cameraDistances.append(randCameraDistance)

        tx = headPositionSequence[frame_number][0] * 100.0
        ty = headPositionSequence[frame_number][2] * 100.0 # y is y in unreal
        tz = headPositionSequence[frame_number][1] * 100.0 # z is z in unreal

        # position in x,y
        yawAngleRad = math.radians(yawAngleDeg)
        x = randCameraDistance * math.cos(yawAngleRad) + tx
        y = randCameraDistance * math.sin(yawAngleRad) + ty
        z = 0 + tz

        transform_channels[0].add_key(time=unreal.FrameNumber(frame_number), new_value=x)  
        transform_channels[1].add_key(time=unreal.FrameNumber(frame_number), new_value=y)  
        transform_channels[2].add_key(time=unreal.FrameNumber(frame_number), new_value=z)  

        cameraPoses.append([x,y,z,yawAngleDeg,pitchAngleDeg,rollAngleDeg])

    return cameraPoses, cameraDistances

def randomize_lighting(level_sequence, numFrames, hdri_name = None, hdri_intensity=1.0):

    # get lighting actor
    actors = unreal.get_editor_subsystem(unreal.EditorActorSubsystem).get_all_level_actors() # deprecated: unreal.EditorLevelLibrary.get_all_level_actors()
    dirlighting_actor = None
    hdri_actor = None
    for actor in actors:
        if actor.get_class().get_name() == "DirectionalLight":
            dirlighting_actor = actor
        if actor.get_class().get_name() == "BE_HDRIBackdrop_C":
            hdri_actor = actor
        else:
            print(actor.get_class().get_name())

    if (dirlighting_actor is not None and hdri_actor is not None):
        dir_lighting_binding = level_sequence.add_possessable(dirlighting_actor)

        # get hdri binding
        hdri_binding = None

        # create hdri binding
        hdri_binding = level_sequence.add_possessable(hdri_actor)

        hdri_path = f"{hdri_root}{hdri_name}{hdri_suffix}"
        unreal.log(f"  Loading HDRI: {hdri_path}")
        hdri_object = unreal.load_object(None, hdri_path)
        if hdri_object is None:
            unreal.log_error("Cannot load HDRI")
            return False
        
        # Set loaded HDRI as Skylight cubemap in sequencer
        for binding in level_sequence.get_possessables():
            binding_name = binding.get_name()
            if (binding_name == "BE_HDRIBackdrop"):
                hdri_binding = binding

            if (binding_name == "Skylight"):
                skylight_binding = binding
                for track in binding.get_tracks():
                    for section in track.get_sections():
                        for channel in section.get_all_channels():
                            channel.set_default(hdri_object)

        # create geometry and material component
        hdri_geometry_component = hdri_actor.get_component_by_class(unreal.StaticMeshComponent)
        hdri_geometry_binding = level_sequence.add_possessable(hdri_geometry_component)
        # create material track and section
        hdri_material_track_floor = hdri_geometry_binding.add_track(unreal.MovieSceneComponentMaterialTrack)
        hdri_material_track_sky = hdri_geometry_binding.add_track(unreal.MovieSceneComponentMaterialTrack)


        hdri_mesh = hdri_actor.get_component_by_class(unreal.StaticMeshComponent)

        hdri_material_track_floor.set_material_index(0) # works but results in missing binding warning
        hdri_material_track_sky.set_material_index(1) # works but results in missing binding warning

        hdri_material_section_floor = hdri_material_track_floor.add_section()
        hdri_material_section_floor.set_start_frame_bounded(False)
        hdri_material_section_floor.set_end_frame_bounded(False)

        hdri_material_section_sky = hdri_material_track_sky.add_section()
        hdri_material_section_sky.set_start_frame_bounded(False)
        hdri_material_section_sky.set_end_frame_bounded(False)


        # Add an intensity track for skylight
        skylight_intensity_track = skylight_binding.add_track(unreal.MovieSceneFloatTrack) 
        skylight_intensity_track.set_property_name_and_path("Intensity", "Intensity")
        skylight_intensity_section = skylight_intensity_track.add_section()
        skylight_intensity_section.set_start_frame_bounded(False)
        skylight_intensity_section.set_end_frame_bounded(False)
        skylight_intensity_channel = skylight_intensity_section.get_all_channels()[0]

        # Create a Light Component and attach it to the Directional Light actor
        light_component = dirlighting_actor.get_component_by_class(unreal.LightComponent)
        # Add the Light Component to the Level Sequence
        light_component_binding = level_sequence.add_possessable(light_component)
    
        if not light_component:
            unreal.log_error("Failed to create light component.")
            return

        # transform binding for light
        transform_track = dir_lighting_binding.add_track(unreal.MovieScene3DTransformTrack)
        transform_section = transform_track.add_section()
        transform_section.set_start_frame_bounded(False)
        transform_section.set_end_frame_bounded(False)
        transform_channels = transform_section.get_all_channels()

        # fill transformation
        if WARMUP_FRAMES > 0:
            transform_channels[4].add_key(time=unreal.FrameNumber(-WARMUP_FRAMES), new_value=270)
            transform_channels[5].add_key(time=unreal.FrameNumber(-WARMUP_FRAMES), new_value=0)
        for frame_number in range (0, numFrames):
            randYawAngle = random.uniform(0, 360)
            transform_channels[5].add_key(time=unreal.FrameNumber(frame_number), new_value=randYawAngle)  
            randPitchAngle = random.uniform(200, 350)
            transform_channels[4].add_key(time=unreal.FrameNumber(frame_number), new_value=randPitchAngle)  

        # Add an intensity track for directional light
        intensity_track = light_component_binding.add_track(unreal.MovieSceneFloatTrack) 
        intensity_track.set_property_name_and_path("Intensity", "Intensity")
        intensity_section = intensity_track.add_section()
        intensity_section.set_start_frame_bounded(False)
        intensity_section.set_end_frame_bounded(False)
        dirLight_intensity_channel = intensity_section.get_all_channels()[0]

        minLightingIntensity = 1.0
        maxLightingIntensity = 14

        hdri_base_intensity_scale = 2.0

        # fill intensity
        if WARMUP_FRAMES > 0:
            dirLight_intensity_channel.add_key(time=unreal.FrameNumber(-WARMUP_FRAMES), new_value=1)
        for frame_number in range (0, numFrames):
            
            randNormLightIntensity = random.uniform(0.0, 1.0) # normalized intensity value as basis for further calculation

            randDirLightIntensity = minLightingIntensity +  randNormLightIntensity * maxLightingIntensity
            
            dirLight_intensity_channel.add_key(time=unreal.FrameNumber(frame_number), new_value=randDirLightIntensity)

            # couple hdri intensity with randomized direct lighting intensity to create realistic scene
            hdri_material_intensity = hdri_base_intensity_scale * (0.3 + (0.7 * randNormLightIntensity)) # scale and bias, don't let scene get too dark, scale with hdri map specific intensity

            skylightIntensity = hdri_material_intensity * hdri_intensity

            # couple skylight intensity with directional light intensity
            skylight_intensity_channel.add_key(time=unreal.FrameNumber(frame_number), new_value=skylightIntensity)

            intensity_parameter = unreal.MaterialParameterInfo("Intensity")
            hdri_material_section_floor.add_scalar_parameter_key(intensity_parameter, unreal.FrameNumber(frame_number)*800, hdri_material_intensity, layer_name="", asset_name="") # scale by 800 for frame tick resolution
            hdri_material_section_sky.add_scalar_parameter_key(intensity_parameter, unreal.FrameNumber(frame_number)*800, hdri_material_intensity, layer_name="", asset_name="") # scale by 800 for frame tick resolution

        # light color for directional light
        color_track = light_component_binding.add_track(unreal.MovieSceneColorTrack) 
        color_track.set_property_name_and_path("Light Color", "LightColor")
        color_section = color_track.add_section()
        color_section.set_start_frame_bounded(False)
        color_section.set_end_frame_bounded(False)
        color_channels = color_section.get_all_channels()

        # fill light color
        if WARMUP_FRAMES > 0:
            color_channels[0].add_key(time=unreal.FrameNumber(-WARMUP_FRAMES), new_value=1)
            color_channels[1].add_key(time=unreal.FrameNumber(-WARMUP_FRAMES), new_value=1)
            color_channels[2].add_key(time=unreal.FrameNumber(-WARMUP_FRAMES), new_value=1)
            color_channels[3].add_key(time=unreal.FrameNumber(-WARMUP_FRAMES), new_value=1)
        for frame_number in range (0, numFrames):
            minColorValue= 0.5
            color_channels[0].add_key(time=unreal.FrameNumber(frame_number), new_value=random.uniform(minColorValue, 1.0))
            color_channels[1].add_key(time=unreal.FrameNumber(frame_number), new_value=random.uniform(minColorValue, 1.0))
            color_channels[2].add_key(time=unreal.FrameNumber(frame_number), new_value=random.uniform(minColorValue, 1.0))
            color_channels[3].add_key(time=unreal.FrameNumber(frame_number), new_value=1.0)
        
    return

def get_focal_length(cine_camera_component, camera_hfov):
    sensor_width = cine_camera_component.filmback.sensor_width
    focal_length = sensor_width / (2.0 * tan(radians(camera_hfov)/2))
    return focal_length

def add_static_camera(level_sequence, camera_actor, camera_pose, camera_hfov):
    """
    Add static camera actor and camera cut track to level sequence.
    """

    # Add camera with transform track
    camera_binding = level_sequence.add_possessable(camera_actor)
    add_transform_track(camera_binding, camera_pose)
    """
    transform_track = camera_binding.add_track(unreal.MovieScene3DTransformTrack)
    transform_section = transform_track.add_section()
    transform_section.set_start_frame_bounded(False)
    transform_section.set_end_frame_bounded(False)
    transform_channels = transform_section.get_all_channels()
    transform_channels[0].set_default(camera_pose.x) # location X
    transform_channels[1].set_default(camera_pose.y) # location Y
    transform_channels[2].set_default(camera_pose.z) # location Z

    transform_channels[3].set_default(camera_pose.roll) # roll
    transform_channels[4].set_default(camera_pose.pitch) # pitch
    transform_channels[5].set_default(camera_pose.yaw) # yaw
    """

    if camera_hfov is not None:
        # Add focal length CameraComponent track to match specified hfov

        # Add a cine camera component binding using the component of the camera actor
        cine_camera_component = camera_actor.get_cine_camera_component()
        camera_component_binding = level_sequence.add_possessable(cine_camera_component)
        camera_component_binding.set_parent(camera_binding)

        # Add a focal length track and default it to 60
        focal_length_track = camera_component_binding.add_track(unreal.MovieSceneFloatTrack)
        focal_length_track.set_property_name_and_path('CurrentFocalLength', 'CurrentFocalLength')
        focal_length_section = focal_length_track.add_section()
        focal_length_section.set_start_frame_bounded(False)
        focal_length_section.set_end_frame_bounded(False)

        focal_length = get_focal_length(cine_camera_component, camera_hfov)
        focal_length_section.get_all_channels()[0].set_default(focal_length)

    camera_cut_track = level_sequence.add_master_track(unreal.MovieSceneCameraCutTrack)
    camera_cut_section = camera_cut_track.add_section()
    camera_cut_section.set_start_frame(-WARMUP_FRAMES) # Use negative frames as warmup frames
    camera_binding_id = unreal.MovieSceneObjectBindingID()
    camera_binding_id.set_editor_property("Guid", camera_binding.get_id())
    camera_cut_section.set_editor_property("CameraBindingID", camera_binding_id)

    return camera_cut_section

def add_focus_stack_camera(level_sequence, camera_actor, camera_pose, camera_hfov, end_frame, headPositionSequence=None, minRadiusSequence=None):
    """
    Add focus stacked camera actor and camera cut track to level sequence.
    """

    cameraFocalLengths = []

    # Add camera with transform track
    camera_binding = level_sequence.add_possessable(camera_actor)
    camMinDistance = 40
    camMaxDistance = 200
    cameraPoses, cameraDistances = add_transform_track_rotation(camera_binding, camera_pose, end_frame, camOriginMinDistance=camMinDistance, camOriginMaxDistance=camMaxDistance,headPositionSequence=headPositionSequence,minRadiusSequence=minRadiusSequence)

    """
    transform_track = camera_binding.add_track(unreal.MovieScene3DTransformTrack)
    transform_section = transform_track.add_section()
    transform_section.set_start_frame_bounded(False)
    transform_section.set_end_frame_bounded(False)
    transform_channels = transform_section.get_all_channels()
    transform_channels[0].set_default(camera_pose.x) # location X
    transform_channels[1].set_default(camera_pose.y) # location Y
    transform_channels[2].set_default(camera_pose.z) # location Z

    transform_channels[3].set_default(camera_pose.roll) # roll
    transform_channels[4].set_default(camera_pose.pitch) # pitch
    transform_channels[5].set_default(camera_pose.yaw) # yaw
    """

    if camera_hfov is not None:
        # Add focal length CameraComponent track to match specified hfov

        # Add a cine camera component binding using the component of the camera actor
        cine_camera_component = camera_actor.get_cine_camera_component()
        camera_component_binding = level_sequence.add_possessable(cine_camera_component)
        camera_component_binding.set_parent(camera_binding)

        # Add a focal length track and default it to 60
        focal_length_track = camera_component_binding.add_track(unreal.MovieSceneFloatTrack)
        focal_length_track.set_property_name_and_path('CurrentFocalLength', 'CurrentFocalLength')
        focal_length_section = focal_length_track.add_section()
        focal_length_section.set_start_frame_bounded(False)
        focal_length_section.set_end_frame_bounded(False)

        # set focal length
        cine_camera_component.filmback.sensor_width = 36 # set to square format
        cine_camera_component.filmback.sensor_height = 36 # set to square format

        default_focal_length = 15.0

        focal_length_section.get_all_channels()[0].set_default(default_focal_length)

        # set key frames for focal length
        focal_length_section.set_range(-WARMUP_FRAMES, end_frame)
        focal_length_channel = focal_length_section.get_all_channels()[0]
        if WARMUP_FRAMES > 0:
            focal_length_channel.add_key(time=unreal.FrameNumber(-WARMUP_FRAMES), new_value=-1)

        for frame_number in range (0, end_frame):

            d = cameraDistances[frame_number]

            # default focal length: 49.5
            dZ = d - 100.0
            Z0 = 100.0
            targetFocalLength = default_focal_length * ((Z0 + dZ) / Z0) # assuming default distance of 100

            # randomize around target focal length
            currentFocalLength = random.uniform(targetFocalLength * 0.7, targetFocalLength * 1.3)

            #currentFocalLength = focal_length

            # dolly zoom: derive focal length from camera distance to target
            # https://www-users.cse.umn.edu/~hspark/CSci5980/ch1.pdf#page=2.55
            # f* = f * ((Z0 + dZ) / Z0)

            focal_length_channel.add_key(time=unreal.FrameNumber(frame_number), new_value=currentFocalLength)        

            cameraFocalLengths.append(currentFocalLength)


    camera_cut_track = level_sequence.add_master_track(unreal.MovieSceneCameraCutTrack)
    camera_cut_section = camera_cut_track.add_section()
    camera_cut_section.set_start_frame(-WARMUP_FRAMES) # Use negative frames as warmup frames
    camera_binding_id = unreal.MovieSceneObjectBindingID()
    camera_binding_id.set_editor_property("Guid", camera_binding.get_id())
    camera_cut_section.set_editor_property("CameraBindingID", camera_binding_id)

    return camera_cut_section, cameraPoses, cameraFocalLengths

def change_binding_end_keyframe_times(binding, new_frame):
    for track in binding.get_tracks():
        for section in track.get_sections():
            for channel in section.get_all_channels():
                channel_keys = channel.get_keys()
                if len(channel_keys) > 0:
                    if len(channel_keys) != 2: # only change end keyframe time if channel has two keyframes
                        unreal.log_error("WARNING: Channel does not have two keyframes. Not changing last keyframe to sequence end frame.")
                    else:
                        end_key = channel_keys[1]
                        end_key.set_time(unreal.FrameNumber(new_frame))

def prepareBedlamAnimationPoses(data):

    pose_list = []
    betas = None
    numAnimationFrames = data['poses'].shape[0]
    numBetas = data['betas'].shape[0] # betas usally fixed
    
    if (betas == None):
        betas = np.zeros([300], dtype=np.float32)
        betas[0:numBetas] = data['betas']

    for frameIndex in range(numAnimationFrames):
                
        pose_concat = np.zeros([265+3])

        # Extract 'betas' and 'poses' arrays from the loaded data
        pose_concat[0:3]      = np.zeros([3], dtype=np.float32)
        pose_concat[9:12]     = data['global_ori'][frameIndex,:]
        pose_concat[12:75]    = data['poses'][frameIndex,3:3+63] # 165: 63 value : 21 x 3
        pose_concat[75:120]   = np.zeros([45], dtype=np.float32)  # 45 value : 15 x 3
        pose_concat[120:165]  = np.zeros([45], dtype=np.float32) # 45 value : 15 x 3
        pose_concat[165:265]  = np.zeros([100], dtype=np.float32)
        
        pose_concat[265:265+3]  = data['trans'][frameIndex,0:3] # 3

        pose_list.append(pose_concat)

    return pose_list

def evaluateNeckJointPositionFromAnimationFile(sequenceFile):

    print(sequenceFile)

    # Load data from each npz file
    animationData = np.load(sequenceFile)

    # compute neck bone position for each frame
    # write into sequence file
    numAnimationFrames = animationData['poses'].shape[0]

    numBetas = animationData['betas'].shape[0] # betas usally fixed
    smplxModel.betas = np.zeros([300], dtype=np.float32)
    smplxModel.betas[0:numBetas] = animationData['betas']
    
    pose_list = prepareBedlamAnimationPoses(animationData)

    neckPositions = []
    minRadius = [] # min radius for camera collision avoidance

    for frameIndex in range(numAnimationFrames):
        
        # update SMPL using pose
        smplxModel.recomputeJointPositionsFromConcatPose(pose_list[frameIndex])

        # first smplx bones
        # 0 "pelvis",
        # 1 "left_hip",
        # 2 "right_hip",
        # 3 "spine1",
        # 4 "left_knee",
        # 5 "right_knee",
        # 6 "spine2",
        # 7 "left_ankle",
        # 8 "right_ankle",
        # 9 "spine3",
        # 10 "left_foot",
        # 11 "right_foot",
        # 12 "neck",
        # 13 "left_collar",
        # 14 "right_collar",
        # 15 "head",

        jointStack = [0,3,6,9,12]

        stackIndex = frameIndex % 5

        jointIndex = jointStack[stackIndex]

        # get position of target joint
        neckPositions.append(smplxModel.joint_positions[0, jointIndex, :]) # stacked joint

        jointsPositionsXZ = 100. * np.copy(smplxModel.joint_positions[0, :, :]) # get a copy of the joint positions, scale from meters to centimeters
        jointsPositionsXZ[:,1] = 0 # set y coordinate to zero as we are only interested in x/z extent (like the persons arms spread out)

        # Get the first point
        firstJoint = jointsPositionsXZ[0]

        # Compute the distances from the first point
        distances = np.linalg.norm(jointsPositionsXZ - firstJoint, axis=1)

        # Find and print the maximum distance
        max_distance = np.max(distances)

        minRadius.append(max_distance * 1.1) # give a bit of extra space between joint and camera

    return neckPositions, minRadius, animationData

def evaluateSmplxAnimationFile(sequenceFile):

    print(sequenceFile)

    # Load data from each npz file
    animationData = np.load(sequenceFile)

    # compute neck bone position for each frame
    # write into sequence file
    numAnimationFrames = animationData['poses'].shape[0]

    numBetas = animationData['betas'].shape[0] # betas usally fixed
    smplxModel.betas = np.zeros([300], dtype=np.float32)
    smplxModel.betas[0:numBetas] = animationData['betas']
    
    pose_list = prepareBedlamAnimationPoses(animationData)

    joint_positions_list = []

    for frameIndex in range(numAnimationFrames):
        
        # update SMPL using pose
        smplxModel.recomputeJointPositionsFromConcatPose(pose_list[frameIndex])

        joint_positions_list.append(smplxModel.joint_positions)

    return joint_positions_list, animationData

def get_random_camera_distance_inverse_z():

    # Sample camera distance in inverse depth
    if np.random.rand() < 0.8:
        # 80% chance: camera within 0.5m to 1m
        s = np.random.uniform(1/1.0, 1/0.5)  # s in [1.0, 2.0]
    else:
        # 20% chance: camera within 1m to 10m
        s = np.random.uniform(1/10.0, 1/1.0)  # s in [0.1, 1.0]

    radius = 1 / s  # Distance from centroid

    radius *= 100.0

    return radius

def rotation_matrix_to_euler_angles(R):
    sy = np.sqrt(R[0,0]**2 + R[1,0]**2)

    singular = sy < 1e-6  # If sy is close to zero, we need to handle the singularity

    if not singular:
        pitch = np.arctan2(R[2,1], R[2,2])
        roll = np.arctan2(-R[2,0], sy)
        yaw = np.arctan2(R[1,0], R[0,0])
    else:
        pitch = np.arctan2(-R[1,2], R[1,1])
        roll = np.arctan2(-R[2,0], sy)
        yaw = 0

    # Convert radians to degrees
    roll_deg = np.degrees(roll)
    pitch_deg = np.degrees(pitch)
    yaw_deg = np.degrees(yaw)

    return roll_deg, pitch_deg, yaw_deg

def get_camera_transform_from_distance_and_target_3d_points(cameraDistance, joint_positions, frameIndex):


    points_3d = joint_positions[0,:,:]

    # target selection

    # method A: Compute the centroid of the points
    #N = points_3d.shape[0]
    #meanPos = np.mean(points_3d, axis=0)
    #centroid = 100. * np.array([ meanPos[0], meanPos[2], meanPos[1] ]) # get a copy of the joint positions, scale from meters to centimeters

    # method B: pick joint position directly
    jointStack = [0,3,6,9,12,15]
    stackIndex = frameIndex % 6
    jointIndex = jointStack[stackIndex]
    
    #jointIndex = 0

    #jointIndex = 15# head joint index
    #jointIndex = 0 # pelvis
    #jointIndex = 9 # spine3
    #jointIndex = 12 # neck joint index
    
    jointX = joint_positions[0, jointIndex, 0]
    jointY = joint_positions[0, jointIndex, 1] # z in unreal
    jointZ = joint_positions[0, jointIndex, 2] # y in unreal
    
    # move joint position further down to visually better align person in view
    jointY = jointY - 0.4 # in meters
    
    centroid = 100. * np.array([ jointX, jointZ, jointY ]) # get a copy of the joint positions, scale from meters to centimeters

    while (True):

        # Randomize spherical coordinates guiding camera rotation
        theta = np.random.uniform(0, 2 * np.pi) # azimuth angle / yaw angle between [0, 2 pi]
        phi = np.random.uniform(0.1 * np.pi, 0.7 * np.pi) # polar angle / pitch angle between [0, pi] # range for v6 of dataset
        
        # Compute camera position
        d = cameraDistance #
        x = d * np.sin(phi) * np.cos(theta) # x - forward
        y = d * np.sin(phi) * np.sin(theta) # - right
        z = d * np.cos(phi) # z - height axis
        camera_position = centroid + np.array([x,y,z])
        camera_position[2] = max(camera_position[2], 5.0) # # make sure to not penetrate the ground, in cm

        # Compute the direction vector towards the centroid (with some random perturbation)
        direction = centroid - camera_position
        directionNoise = ((1/d) * 500.0) * np.random.normal(size=3)  # Add noise proportional to camera distance
        direction += directionNoise  # Add noise proportional to radius
        
        # Normalize the direction vector
        direction /= np.linalg.norm(direction)

        # Define the up vector (avoid being parallel to the direction vector)
        up_guess = np.array([0, 0, 1])  # z is up
        if np.abs(np.dot(direction, up_guess)) > 0.9:
            up_guess = np.array([1, 0, 0])

        # Compute the camera right vector
        right = np.cross(direction, up_guess)
        right /= np.linalg.norm(right)

        # Recompute the true up vector
        up = np.cross(right, direction)
        up /= np.linalg.norm(up)

        # Build the camera rotation matrix
        R = np.vstack([right, direction, up]).T  # 3x3 rotation matrix

        # Compute the extrinsic matrix
        roll_deg, pitch_deg, yaw_deg = rotation_matrix_to_euler_angles(R)

        yaw_deg = yaw_deg - 90 + 180.0 # not sure why this conversion is required
        
        if (roll_deg == 0.0): # sanity check for good pose
            break

    return camera_position[0], camera_position[1], camera_position[2], yaw_deg, pitch_deg, roll_deg


def add_actor_centric_randomized_camera(level_sequence, camera_actor, camera_pose, camera_hfov, numFrames, subject, animation_id):
    
    global animationRootDir

    assert camera_hfov is not None

    default_focal_length = 15.0

    animationSequenceFile = animationRootDir + subject + '/moving_body_para/' + animation_id + '/motion_seq.npz' # to evaluate head pose of animation

    # evaluate animation data    
    joint_positions_list, animationData = evaluateSmplxAnimationFile(animationSequenceFile)

    print(f"Number of sequence frames {numFrames}")
    print(f"Number of animation frames {len(joint_positions_list)}") 

    # create tracks for camera position, camera rotation and focal length

    # Add a cine camera component binding using the component of the camera actor
    camera_binding = level_sequence.add_possessable(camera_actor)
    cine_camera_component = camera_actor.get_cine_camera_component()
    camera_component_binding = level_sequence.add_possessable(cine_camera_component)
    camera_component_binding.set_parent(camera_binding)

    # Add a focal length track and default it to 60
    focal_length_track = camera_component_binding.add_track(unreal.MovieSceneFloatTrack)
    focal_length_track.set_property_name_and_path('CurrentFocalLength', 'CurrentFocalLength')
    focal_length_section = focal_length_track.add_section()
    focal_length_section.set_start_frame_bounded(False)
    focal_length_section.set_end_frame_bounded(False)

    # set sensor size and default focal length
    cine_camera_component.filmback.sensor_width = 36 # set to square format
    cine_camera_component.filmback.sensor_height = 36 # set to square format

    focal_length_section.get_all_channels()[0].set_default(default_focal_length)

    # set key frames for focal length
    focal_length_section.set_range(-WARMUP_FRAMES, numFrames)
    focal_length_channel = focal_length_section.get_all_channels()[0]
    if WARMUP_FRAMES > 0:
        focal_length_channel.add_key(time=unreal.FrameNumber(-WARMUP_FRAMES), new_value=-1)

    # create camera transform track
    transform_track = camera_binding.add_track(unreal.MovieScene3DTransformTrack)
    transform_section = transform_track.add_section()
    transform_section.set_start_frame_bounded(False)
    transform_section.set_end_frame_bounded(False)
    transform_channels = transform_section.get_all_channels()
    transform_channels[0].set_default(camera_pose.x) # location X
    transform_channels[1].set_default(camera_pose.y) # location Y
    transform_channels[2].set_default(camera_pose.z) # location Z

    transform_channels[3].set_default(camera_pose.roll) # roll
    transform_channels[4].set_default(camera_pose.pitch) # pitch
    transform_channels[5].set_default(camera_pose.yaw) # yaw

    if WARMUP_FRAMES > 0:
        transform_channels[5].add_key(time=unreal.FrameNumber(-WARMUP_FRAMES), new_value=-1)

    cameraFocalLengths  = []
    cameraPoses         = []
    cameraDistances     = []

    for frame_number in range (0, numFrames):

        # sample camera distance
        d = np.random.uniform(6.0, 10.0)  # in meters

        d *= 100.0 # m to cm
        
        # sample focal length

        # dolly zoom: derive focal length from camera distance to target
        # https://www-users.cse.umn.edu/~hspark/CSci5980/ch1.pdf#page=2.55
        # f* = f * ((Z0 + dZ) / Z0)

        dZ = d - 100.0
        Z0 = 100.0
        targetFocalLength = default_focal_length * ((Z0 + dZ) / Z0) # assuming default distance of 100

        # randomize around target focal length
        #currentFocalLength = random.uniform(targetFocalLength * 0.7, targetFocalLength * 1.3)
        currentFocalLength = targetFocalLength

        # get actor's joint locations in 3d space
        currrentJoints = joint_positions_list[frame_number+1] # animation frame is off by one ?

        # compute camera rotation towards actor
        cam_x, cam_y, cam_z, yawAngleDeg, pitchAngleDeg, rollAngleDeg = get_camera_transform_from_distance_and_target_3d_points(d, currrentJoints, frame_number)

        # save information
        cameraDistances.append(d)
        cameraFocalLengths.append(currentFocalLength)
        cameraPoses.append([cam_x, cam_y, cam_z, yawAngleDeg, pitchAngleDeg, rollAngleDeg])

        # add key for focal length
        focal_length_channel.add_key(time=unreal.FrameNumber(frame_number), new_value=currentFocalLength) # focal length
        # add keys for camera transform
        transform_channels[0].add_key(time=unreal.FrameNumber(frame_number), new_value=cam_x)  
        transform_channels[1].add_key(time=unreal.FrameNumber(frame_number), new_value=cam_y)  
        transform_channels[2].add_key(time=unreal.FrameNumber(frame_number), new_value=cam_z) 
        transform_channels[3].add_key(time=unreal.FrameNumber(frame_number), new_value=rollAngleDeg)   
        transform_channels[4].add_key(time=unreal.FrameNumber(frame_number), new_value=pitchAngleDeg)   
        transform_channels[5].add_key(time=unreal.FrameNumber(frame_number), new_value=yawAngleDeg)   


    # add camera cut track -> not sure why we need this
    camera_cut_track = level_sequence.add_master_track(unreal.MovieSceneCameraCutTrack)
    camera_cut_section = camera_cut_track.add_section()
    camera_cut_section.set_start_frame(-WARMUP_FRAMES) # Use negative frames as warmup frames
    camera_binding_id = unreal.MovieSceneObjectBindingID()
    camera_binding_id.set_editor_property("Guid", camera_binding.get_id())
    camera_cut_section.set_editor_property("CameraBindingID", camera_binding_id)

    return camera_cut_section, cameraPoses, cameraFocalLengths, cameraDistances, animationData

def add_level_sequence(name, camera_actor, camera_pose, ground_truth_logger_actor, sequence_bodies, sequence_frames, hdri_name, hdri_intensity, camera_hfov=None, camera_movement="Static", cameraroot_yaw=None, cameraroot_location=None, subject=None, animation_id=None, outputDir=None):
    asset_tools = unreal.AssetToolsHelpers.get_asset_tools()

    level_sequence_path = level_sequences_root + name

    # Check for existing LevelSequence and delete it to avoid message dialog when creating asset which exists
    if unreal.EditorAssetLibrary.does_asset_exist(level_sequence_path):
        unreal.log("  Deleting existing old LevelSequence: " + level_sequence_path)
        unreal.EditorAssetLibrary.delete_asset(level_sequence_path)

    level_sequence = unreal.EditorAssetLibrary.duplicate_asset(level_sequence_hdri_template, level_sequence_path)

    # Set frame rate to 30fps
    frame_rate = unreal.FrameRate(numerator = 30, denominator = 1)
    level_sequence.set_display_rate(frame_rate)

    # randomize lighting (directional light + skylight)
    randomize_lighting(level_sequence, sequence_frames, hdri_name=hdri_name, hdri_intensity=hdri_intensity)

    cameraroot_binding = None

    if camera_movement == "Static":

        # Create camera animation

        # randomized camera considering actor animation
        camera_cut_section, cameraPoses, cameraFocalLengths, cameraDistances, animationData = add_actor_centric_randomized_camera(level_sequence, camera_actor, camera_pose, camera_hfov, sequence_frames, subject, animation_id)

        cameraFolder = outputDir + '/info/' + name + '/'
        cameraFile = cameraFolder + 'camera_smplx.npz'
        print('Camera file')
        print(cameraFile)
        os.makedirs(cameraFolder, exist_ok=True)

        # write camera motion: 
        # /info/seq_000000/camera.npz
        # focal length
        # pose
        # subject_id
        # animation_id

        # write camera motion
        np.savez(cameraFile,
                 cam_pose=np.asarray(cameraPoses, dtype=np.float32),
                 cam_distances=np.asarray(cameraDistances, dtype=np.float32),
                 focal_length=np.asarray(cameraFocalLengths, dtype=np.float32),
                 subject_id=subject,
                 animation_id=animation_id,
                 motion_info=animationData['motion_info'],
                 smplx_betas=animationData['betas'],
                 smplx_poses=animationData['poses'],
                 smplx_global_ori=animationData['global_ori'],
                 smplx_trans=animationData['trans']) # including smplx parameters
        
        # free memory
        animationData = None

    else:
        # Use existing camera from LevelSequence template
        master_track = level_sequence.get_master_tracks()[0]
        camera_cut_section = master_track.get_sections()[0]
        camera_cut_section.set_start_frame(-WARMUP_FRAMES) # Use negative frames as warmup frames

        if camera_movement.startswith("Zoom") or camera_movement.startswith("Orbit"):
            # Add camera transform track and set static camera pose
            for binding in level_sequence.get_possessables():
                binding_name = binding.get_name()
                if binding_name == "BE_CineCameraActor_Blueprint":
                    add_transform_track(binding, camera_pose)

                if binding_name == "CameraComponent":
                    # Set HFOV
                    focal_length = get_focal_length(camera_actor.get_cine_camera_component(), camera_hfov)
                    binding.get_tracks()[0].get_sections()[0].get_all_channels()[0].set_default(focal_length)

                if camera_movement.startswith("Zoom"):
                    if binding_name == "CameraComponent":
                        # Set end focal length keyframe time to end of sequence
                        change_binding_end_keyframe_times(binding, sequence_frames)
                elif camera_movement.startswith("Orbit"):
                    if binding_name == "BE_CameraRoot":
                        cameraroot_binding = binding
                        change_binding_end_keyframe_times(binding, sequence_frames)

    if (cameraroot_yaw is not None) or (cameraroot_location is not None):
        cameraroot_actor = camera_actor.get_attach_parent_actor()
        if cameraroot_actor is None:
            unreal.log_error("Cannot find camera root actor for CineCameraActor")
            return False

        transform_channels = None
        if cameraroot_binding is None:
            # Add camera root actor to level sequence
            cameraroot_binding = level_sequence.add_possessable(cameraroot_actor)
            transform_track = cameraroot_binding.add_track(unreal.MovieScene3DTransformTrack)
            transform_section = transform_track.add_section()
            transform_section.set_start_frame_bounded(False)
            transform_section.set_end_frame_bounded(False)
            transform_channels = transform_section.get_all_channels()
            if (cameraroot_yaw is not None):
                transform_channels[5].set_default(cameraroot_yaw) # yaw
            else:
                transform_channels[5].set_default(0.0)
        else:
            if cameraroot_yaw is not None:
                # Add cameraroot to existing keyframed yaw values
                transform_channels = cameraroot_binding.get_tracks()[0].get_sections()[0].get_all_channels()
                yaw_channel = transform_channels[5]
                channel_keys = yaw_channel.get_keys()
                for key in channel_keys:
                    key.set_value(key.get_value() + cameraroot_yaw)

        if cameraroot_location is None:
            cameraroot_location = cameraroot_actor.get_actor_location() # Default camera root location is not automatically taken from level actor when adding track via Python

        transform_channels[0].set_default(cameraroot_location.x)
        transform_channels[1].set_default(cameraroot_location.y)
        transform_channels[2].set_default(cameraroot_location.z)

    """
    # Get end frame from body sequence
    body_object = unreal.load_object(None, body_path)
    # Python Alembic import bug in 4.27.1 makes cache longer by one frame
    # Example: 
    #   126 frame sequence gets imported as end_frame=127
    #   Last frame for Movie Render Queue is (end_frame-1)
    #   We need to set end_frame 126 to ensure that [0, 125] is rendered out.
    end_frame = body_object.end_frame - 1
    """
    end_frame = sequence_frames
    camera_cut_section.set_end_frame(end_frame)
    level_sequence.set_playback_start(-WARMUP_FRAMES) # Use negative frames as warmup frames
    level_sequence.set_playback_end(end_frame)

    # Add ground truth logger if available and keyframe sequencer frame numbers into Frame variable
    if ground_truth_logger_actor is not None:
        logger_binding = level_sequence.add_possessable(ground_truth_logger_actor)

        frame_track = logger_binding.add_track(unreal.MovieSceneIntegerTrack)
        frame_track.set_property_name_and_path('Frame', 'Frame')
        frame_track_section = frame_track.add_section()
        frame_track_section.set_range(-WARMUP_FRAMES, end_frame)
        frame_track_channel = frame_track_section.get_all_channels()[0]
        if WARMUP_FRAMES > 0:
            frame_track_channel.add_key(time=unreal.FrameNumber(-WARMUP_FRAMES), new_value=-1)

        for frame_number in range (0, end_frame):
            frame_track_channel.add_key(time=unreal.FrameNumber(frame_number), new_value=frame_number)

        # Add level sequence name
        sequence_name_track = logger_binding.add_track(unreal.MovieSceneStringTrack)
        sequence_name_track.set_property_name_and_path('SequenceName', 'SequenceName')
        sequence_name_section = sequence_name_track.add_section()
        sequence_name_section.set_start_frame_bounded(False)
        sequence_name_section.set_end_frame_bounded(False)

        sequence_name_section.get_all_channels()[0].set_default(name)

    for sequence_body_index, sequence_body in enumerate(sequence_bodies):

        body_object = unreal.load_object(None, sequence_body.body_path)
        if body_object is None:
            unreal.log_error(f"Cannot load body asset: {sequence_body.body_path}")
            return False

        animation_start_frame = -sequence_body.start_frame
        animation_end_frame = sequence_frames

        # Check if we use clothing overlay textures instead of textured clothing geometry
        if sequence_body.texture_clothing_overlay is not None:

            if sequence_body.texture_body.startswith("skin_f"):
                gender = "female"
            else:
                gender = "male"

            # Set Soft Object Paths to textures
            texture_body_path = f"Texture2D'{texture_body_root}/{gender}/skin/{sequence_body.texture_body}.{sequence_body.texture_body}'"
            texture_clothing_overlay_path = f"Texture2D'{texture_clothing_overlay_root}/{sequence_body.texture_clothing_overlay}.{sequence_body.texture_clothing_overlay}'"

            add_geometry_cache(level_sequence, sequence_body_index, "body", animation_start_frame, animation_end_frame, body_object, sequence_body.x, sequence_body.y, sequence_body.z, sequence_body.yaw, sequence_body.pitch, sequence_body.roll, None, texture_body_path, texture_clothing_overlay_path)

        else:
            # Add body
            material = None
            if sequence_body.texture_body is not None:
                material_asset_path = f"{material_body_root}/MI_{sequence_body.texture_body}"
                material = unreal.EditorAssetLibrary.load_asset(f"MaterialInstanceConstant'{material_asset_path}'")
                if not material:
                    unreal.log_error(f"Cannot load material: {material_asset_path}")
                    return False

            add_geometry_cache(level_sequence, sequence_body_index, "body", animation_start_frame, animation_end_frame, body_object, sequence_body.x, sequence_body.y, sequence_body.z, sequence_body.yaw, sequence_body.pitch, sequence_body.roll, material)

            # Add clothing if available
            if sequence_body.clothing_path is not None:
                clothing_object = unreal.load_object(None, sequence_body.clothing_path)
                if clothing_object is None:
                    unreal.log_error(f"Cannot load clothing asset: {sequence_body.clothing_path}")
                    return False

                material = None
                if sequence_body.texture_clothing is not None:
                    material_asset_path = f"{material_clothing_root}/{sequence_body.subject}/MI_{sequence_body.subject}_{sequence_body.texture_clothing}"
                    material = unreal.EditorAssetLibrary.load_asset(f"MaterialInstanceConstant'{material_asset_path}'")
                    if not material:
                        unreal.log_error(f"Cannot load material: {material_asset_path}")
                        return False

                add_geometry_cache(level_sequence, sequence_body_index, "clothing", animation_start_frame, animation_end_frame, clothing_object, sequence_body.x, sequence_body.y, sequence_body.z, sequence_body.yaw, sequence_body.pitch, sequence_body.roll, material)

        # Add hair
        if sequence_body.hair_path is not None:
            success = add_hair(level_sequence, sequence_body_index, "hair", animation_start_frame, animation_end_frame, sequence_body.hair_path, sequence_body.animation_path, sequence_body.x, sequence_body.y, sequence_body.z, sequence_body.yaw, sequence_body.pitch, sequence_body.roll)
            if not success:
                return False

    unreal.EditorAssetLibrary.save_asset(level_sequence.get_path_name())

    return True

######################################################################
# Main
######################################################################
if __name__ == '__main__':        
    unreal.log("============================================================")
    unreal.log("Running: %s" % __file__)

    if len(sys.argv) >= 2:
        csv_path = sys.argv[1]

        csv_folder = os.path.dirname(csv_path)

    camera_movement = "Static"
    if len(sys.argv) >= 3:
        camera_movement = sys.argv[2]

    start_time = time.perf_counter()

    # Find CineCameraActor and BE_GroundTruthLogger in current map
    actors = unreal.get_editor_subsystem(unreal.EditorActorSubsystem).get_all_level_actors() # deprecated: unreal.EditorLevelLibrary.get_all_level_actors()
    camera_actor = None
    ground_truth_logger_actor = None
    for actor in actors:
        if actor.static_class() == unreal.CineCameraActor.static_class():
            camera_actor = actor
        elif actor.get_class().get_name() == "BE_GroundTruthLogger_C":
            ground_truth_logger_actor = actor

    success = True

    if camera_actor is None:
        unreal.log_error("Cannot find CineCameraActor in current map")
        success = False
    else:
        # Generate LevelSequences for defined sequences in csv file
        csv_reader = None
        with open(csv_path, mode="r") as csv_file:

            csv_reader = csv.DictReader(csv_file)
            csv_rows = list(csv_reader) # Convert to list of rows so that we can look ahead, this will skip header
            sequence_bodies = []

            sequence_name = None
            sequence_frames = 0
            hdri_name = None
            camera_hfov = None
            camera_pose = None
            cameraroot_yaw = None
            cameraroot_location = None

            for row_index, row in enumerate(csv_rows):
                if row["Type"] == "Comment":
                    continue

                if row["Type"] == "Group":
                    camera_pose = CameraPose(float(row["X"]), float(row["Y"]), float(row["Z"]), float(row["Yaw"]), float(row["Pitch"]), float(row["Roll"]))

                    # Parse additional group configuration
                    values = row["Comment"].split(";")
                    dict_keys = []
                    dict_values = []
                    for value in values:
                        dict_keys.append(value.split("=")[0])
                        dict_values.append(value.split("=")[1])
                    group_config = dict(zip(dict_keys, dict_values))
                    sequence_name = group_config["sequence_name"]
                    sequence_frames = int(group_config["frames"])

                    hdri_images = [
                        "abandoned_church","abandoned_hopper_terminal_03",
                        "abandoned_hopper_terminal_04","abandoned_parking","abandoned_tank_farm_01",
                        "abandoned_tank_farm_02","abandoned_tank_farm_03","abandoned_tank_farm_04","abandoned_waterworks",
                        "air_museum_playground","approaching_storm","autumn_hockey","autumn_park","autumn_road",
                        "beach_parking","between_bridges","blouberg_sunrise_1","blouberg_sunrise_2","blue_lagoon",
                        "circus_maximus_1","circus_maximus_2","cloudy_vondelpark","colosseum","derelict_underpass",
                        "dresden_square","dry_field","dry_hay_field","eilenriede_park","fish_hoek_beach","freight_station","greenwich_park_03",
                        "green_point_park","industrial_sunset","konzerthaus","learner_park","lilienstein","lot_01","lot_02","lythwood_field",
                        "mall_parking_lot","moonlit_golf","mud_road","museumplein","noon_grass","old_bus_depot","old_depot","old_outdoor_theater",
                        "old_quarry_gerlingen","outdoor_umbrellas","park_parking","partial_eclipse","piazza_san_marco","quarry_01","quarry_02",
                        "quarry_03","quarry_04","qwantani","red_hill_straight","reichstag_1","rooitou_park","round_platform","rural_winter_roadside",
                        "shanghai_riverside","small_hangar_01","small_rural_road_02","snowy_field","snowy_forest_path_02","snowy_hillside",
                        "snowy_park_01","snow_field","spiaggia_di_mondello","spruit_sunrise","stadium_01","suburban_field_01","suburban_field_02",
                        "sunflowers","sunny_vondelpark","sunset_fairway","sunset_in_the_chalk_quarry","teatro_massimo","teufelsberg_ground_2",
                        "tiber_island","tiergarten"]
                    
                    numHdriImages = len(hdri_images)

                    hdri_intensity_scale = []
                    for hdri_index in range(numHdriImages):

                        hdri_intensity_scale.append(1.0)

                    hdri_intensity_scale[5] = 3.0

                    # get sequence number
                    numbers = re.findall(r'\d+', sequence_name)
                    sequenceNumber = 0
                    if numbers:
                        sequenceNumber = int(numbers[-1])

                    hdri_name = hdri_images[sequenceNumber % numHdriImages]

                    hdri_intensity = hdri_intensity_scale[sequenceNumber % numHdriImages]

                    # Check if camera HFOV was specified
                    if "camera_hfov" in group_config:
                        camera_hfov = float(group_config["camera_hfov"])
                    else:
                        camera_hfov = None

                    if "cameraroot_yaw" in group_config:
                        cameraroot_yaw = float(group_config["cameraroot_yaw"])
                    else:
                        cameraroot_yaw = None

                    if "cameraroot_x" in group_config:
                        cameraroot_x =float(group_config["cameraroot_x"])
                        cameraroot_y =float(group_config["cameraroot_y"])
                        cameraroot_z =float(group_config["cameraroot_z"])
                        cameraroot_location = unreal.Vector(cameraroot_x, cameraroot_y, cameraroot_z)

                    unreal.log(f"  Generating level sequence: {sequence_name}, frames={sequence_frames}, hdri={hdri_name}, camera_hfov={camera_hfov}")
                    sequence_bodies = []

                    continue

                if row["Type"] == "Body":
                    index = int(row["Index"])
                    body = row["Body"]

                    x = float(row["X"])
                    y = float(row["Y"])
                    z = float(row["Z"])
                    yaw = float(row["Yaw"])
                    pitch = float(row["Pitch"])
                    roll = float(row["Roll"])

                    # Parse additional body configuration
                    values = row["Comment"].split(";")
                    dict_keys = []
                    dict_values = []
                    for value in values:
                        dict_keys.append(value.split("=")[0])
                        dict_values.append(value.split("=")[1])
                    body_config = dict(zip(dict_keys, dict_values))
                    start_frame = 0
                    if "start_frame" in body_config:
                        start_frame = int(body_config["start_frame"])

                    texture_body = None
                    if "texture_body" in body_config:
                        texture_body = body_config["texture_body"]

                    texture_clothing = None
                    if "texture_clothing" in body_config:
                        texture_clothing = body_config["texture_clothing"]

                    texture_clothing_overlay = None
                    if "texture_clothing_overlay" in body_config:
                        texture_clothing_overlay = body_config["texture_clothing_overlay"]

                    hair_path = None
                    if "hair" in body_config:
                        if not level_sequence_hdri_template.endswith("_Hair"):
                            level_sequence_hdri_template += "_Hair"

                        hair_type = body_config["hair"]
                        # StaticMesh'/Engine/PS/Bedlam/Hair/CC/Meshes/SMPLX_M_Hair_Center_part_curtains/SMPLX_M_Hair_Center_part_curtains.SMPLX_M_Hair_Center_part_curtains'
                        hair_path = f"StaticMesh'{hair_root}{hair_type}/{hair_type}.{hair_type}'"

                    match = re.search(r"(.+)_(.+)", body)
                    if not match:
                        unreal.log_error(f"Invalid body name pattern: {body}")
                        success = False
                        break

                    subject = match.group(1)
                    animation_id = match.group(2)

                    body_path = f"GeometryCache'{body_root}{subject}/{body}.{body}'"

                    have_body = unreal.EditorAssetLibrary.does_asset_exist(body_path)
                    if not have_body:
                        unreal.log_error("No asset found for body path: " + body_path)
                        success = False
                        break

                    unreal.log("    Processing body: " + body_path)

                    clothing_path = None
                    if texture_clothing is not None:
                        clothing_path = body_path.replace("SMPLX", "Clothing")
                        clothing_path = clothing_path.replace(animation_id, f"{animation_id}_clo")

                        have_clothing = unreal.EditorAssetLibrary.does_asset_exist(clothing_path)
                        if not have_clothing:
                            #unreal.log_error("No asset found for clothing path: " + clothing_path)
                            clothing_path = None
                        #    success = False
                        #   break
                        else:
                            unreal.log("    Clothing: " + clothing_path)

                    animation_path = None
                    if hair_path is not None:
                        animation_path = f"AnimSequence'{animation_root}{subject}/{body}_Anim.{body}_Anim'"

                    sequence_body = SequenceBody(subject, body_path, clothing_path, hair_path, animation_path, x, y, z, yaw, pitch, roll, start_frame, texture_body, texture_clothing, texture_clothing_overlay)
                    sequence_bodies.append(sequence_body)

                    # Check if body was last item in current sequence
                    add_sequence = False
                    if index >= (len(csv_rows) - 1):
                        add_sequence = True
                    elif csv_rows[row_index + 1]["Type"] != "Body":
                        add_sequence = True

                    if add_sequence:
                        success = add_level_sequence(sequence_name, camera_actor, camera_pose, ground_truth_logger_actor, sequence_bodies, sequence_frames, hdri_name, hdri_intensity, camera_hfov, camera_movement, cameraroot_yaw, cameraroot_location, subject, animation_id, outputDir=csv_folder)

                        # Remove added layers used for segmentation mask naming
                        layer_subsystem = unreal.get_editor_subsystem(unreal.LayersSubsystem)
                        layer_names = layer_subsystem.add_all_layer_names_to()
                        for layer_name in layer_names:
                            if str(layer_name).startswith("be_actor"):
                                layer_subsystem.delete_layer(layer_name)

                        if not success:
                            break

    if success:
        unreal.log(f"LevelSequence generation finished. Total time: {(time.perf_counter() - start_time):.1f}s")
        sys.exit(0)
    else:
        unreal.log_error(f"LevelSequence generation failed. Total time: {(time.perf_counter() - start_time):.1f}s")
        sys.exit(1)
